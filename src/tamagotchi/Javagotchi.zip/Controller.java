package tamagotchi;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Controller {
	
	private int day;
	private int snackCount; 
	private Character character;
	
	public Controller() {
		
	}
	
	public void newGame(Scanner scan) {
		
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("✦ ╮ ");
		System.out.println("  │ ");
		System.out.println("  │ 	자바고치의 이름을 입력해주세요.");
		System.out.println("  │ ");
		System.out.println("  ╰─────────────────────────────────────────────── 🐙");
		String name = scan.nextLine();
		character = new Character(name);
		day = 1;
		
	}
	
	public void saveGame() {
		
		String fileName = "./tamagotchi_data.txt";
		
		try {

			FileWriter fw = new FileWriter(fileName);

			fw.write(String.format("%d\n", day));
			fw.write(String.format("%d\n", snackCount));
			fw.write(String.format("%s\n", character.getCharacterName()));
			fw.write(String.format("%d\n", character.getCharacterStamina()));
			fw.write(String.format("%d\n", character.getCharacterClean()));
			fw.write(String.format("%d\n", character.getCharacterExp()));
			fw.write(String.format("%d\n", character.getCharacterLevel()));

			fw.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void loadGame() {
		
		String fileName = "./tamagotchi_data.txt";
		
		try {
			
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			
			day = Integer.parseInt(br.readLine());
			snackCount = Integer.parseInt(br.readLine());
			
			String name = br.readLine();
			character = new Character(name);
			character.setCharacterStamina( Integer.parseInt(br.readLine()) );
			character.setCharacterClean( Integer.parseInt(br.readLine()) );
			character.setCharacterExp(Integer.parseInt(br.readLine()));
			character.setCharacterLevel(Integer.parseInt(br.readLine()));

			br.close();
		} catch (FileNotFoundException e) {		// 저장된 데이터가 없는 경우
			e.printStackTrace();
		} catch (NumberFormatException e) {		// 저장된 데이터가 손상된 경우
			e.printStackTrace();
		} catch (IOException e) {				// 저장된 데이터가 손상된 경우
			e.printStackTrace();
		}
		
	}
	
	public boolean feed() {
		
		if (snackCount == 0) {
			System.out.println(" ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ ");
			System.out.println(" ┃     ⚠️ 먹이가 부족합니다!     ┃ ");
			System.out.println(" ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ ");
			return false;
		} 
		
		if (character.getCharacterStamina() == 80) {
			System.out.println(" ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ ");
			System.out.println(" ┃     ⚠️ 배가 너무 불러요!      ┃ ");
			System.out.println(" ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ ");
			return false;
		}
		
		snackCount--;
		character.gainExp(10);
		character.gainStamina(15);
		
		return true;
	}
	
	public boolean takeWalk() {
		
		if (!staminaCheck(15)) return false;

		character.loseClean(8);
		character.loseStamina(15);
		character.gainExp(15);
		 
		 return true;
	}
	
	public boolean wash() {
		
		if (!staminaCheck(5)) return false;
		
		character.gainClean(20);
		character.loseStamina(5);
		character.gainExp(5);
		
		return true;
		
	}
	
	public boolean playGame(Scanner scan) {
		
		if (!staminaCheck(20)) return false;
		
		MiniGame game;
		
	        try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		System.out.println("✦ ╮ ");
		System.out.println("  │ ");
		System.out.println("  │        어떤 게임으로 놀아주실 건가요? "); 
		System.out.println("  │ ");
		System.out.println("  ╰─────────────────────────────────────────────── 🐙");
		System.out.println("  ⯎━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⯎ ");
		System.out.println(" ┃                              ┃                             ┃ ");
		System.out.println(" ┃       ⑴ 사칙연산            ┃        ⑵ 영단어퀴즈        ┃ ");
		System.out.println(" ┃                              ┃                             ┃ ");
		System.out.println(" ┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃ ");
		System.out.println(" ┃                              ┃                             ┃ ");
		System.out.println(" ┃        ⑶ 숫자게임           ┃       ⑷ 가위바위보         ┃ ");
		System.out.println(" ┃                              ┃                             ┃ ");
		System.out.println(" ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ ");
		
		int mode;
		while (true) {
			try {
				System.out.print("✦ ");
				mode = scan.nextInt();
				scan.nextLine();
				if (mode < 1 || mode > 4) continue;
				break;
				
			} catch (InputMismatchException e) {
				scan.nextLine();
				System.out.print("✦ ");
			}
		}
		
		switch(mode) {
		case 1:	game = new MathGame(scan); 	break;
		case 2:	game = new EngGame(scan);	break;
		case 3: game = new NumGame(scan);	break;
		case 4: game = new RspGame(scan);	break;
		default: game = new MathGame(scan);		// 여기까지 오면 안 되지만 초기화는 해야 하므로
		}
		
		game.start();
		snackCount += game.getRewardSnack();
		character.loseStamina(20);
		
		if (!game.failed()) return character.gainExp(25);
		
		
		return false;
	}
	
	public void sleep() {
		
		playDiary();
		
		character.loseClean(3);
		character.setCharacterStamina(80);
		
		if (character.getCharacterClean() <= 9)
			character.loseExp(5);
		
		day += 1;
	}
	
	private void playDiary() {
		
	}
	
	public boolean staminaCheck(int amount) {
		return character.getCharacterStamina() >= amount;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getSnackCount() {
		return snackCount;
	}

	public void setSnackCount(int snackCount) {
		this.snackCount = snackCount;
	}

	public Character getCharacter() {
		return character;
	}

	public void setCharacter(Character character) {
		this.character = character;
	}
	
	

}
