package tamagotchi;

import java.util.Random;
import java.util.Scanner;

public class MathGameSingle {
	
	private int num1;
	private int num2;
	private int out;
	private String operator;
	private String[] operlist = {"+", "-", "*", "/"};
	
	private String answer;
	private boolean success;
	
	private Random random = new Random();
	private Scanner scan;
	
	public MathGameSingle(Scanner scan) {
		this.scan = scan;
	}
	
	public void generateEquation() {
		num1 = (int)(random.nextInt(10))+1;
		num2 = (int)(random.nextInt(10))+1;
		operator = operlist[(int)(random.nextInt(4))];
		switch (operator) {
		case "+": out = num1 + num2; break;
		case "-": out = num1 - num2; break;
		case "*": out = num1 * num2; break;
		case "/": num1 = num1 * num2; out = num1 / num2; break;
		}
	}
	
	public String generateQuestion() {
		String question;
		switch (random.nextInt(4)) {
		case 0:
			answer = Integer.toString(num1);
			question = String.format("		( ) %s %d = %d\n		빈칸에 들어갈 숫자는 무엇일까요??", operator, num2, out);
			break;
		case 1:
			answer = Integer.toString(num2);
			question = String.format("		%d %s ( ) = %d\n		빈칸에 들어갈 숫자는 무엇일까요??", num1, operator, out);
			break;
		case 2:
			answer = Integer.toString(out);
			question = String.format("		%d %s %d = ( )\n		빈칸에 들어갈 숫자는 무엇일까요??", num1, operator, num2);
			break;
		default:
			answer = operator;
			question = String.format("		%d ( ) %d = %d\n		빈칸에 들어갈 연산자는 무엇일까요??", num1, num2, out);
		}
		return question;
	}
	
	public String getCorrectText() {
		return "	정답이에요!";
	}
	
	public String getWrongText() {
		return String.format("	정답이 아니에요.... 정답: %s", out);
	}
	
	public String startGame() {
		generateEquation();
		return generateQuestion();
	}
	
	public String checkAnswer() {
		String userAnswer = scan.nextLine();
		if(userAnswer.equals(answer)) {
			success = true;
			return getCorrectText();
		}
		else {
			return getWrongText();
		}
	}

	public boolean isSuccess() {
		return success;
	}
	
}