package tamagotchi;

import java.util.Scanner;

public class TamagotchiMain {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);		
		Controller control = new Controller();	
		TamagotchiScript ts = new TamagotchiScript(control); 
		
		control.newGame(scan);
		String charName = control.getCharacter().getCharacterName();
		
		ts.HelloScript();

		int day = control.getDay();
			
			
			while(true) {	
				
				int stamina = control.getCharacter().getCharacterStamina();
				int level = control.getCharacter().getCharacterLevel();
				day = control.getDay();
				
				if(day == 7) {
					ts.endingScript(charName, level);
					break;
				}
				
				
				ts.Tamagotchi(day, charName, stamina, level);
				
				int select = scan.nextInt();
				
				if(select == 6) 
				{
					ts.byeScript(charName);
					break; }
				
				try {
					
					switch(select) {
					case 1: ts.FeedScript(charName, level); break;
					case 2: ts.WalkScript(charName, level); break;
					case 3: control.playGame(scan); break;
					case 4: ts.WashScript(charName); break;
					case 5: ts.SleepScript(charName); break;
					default: System.out.println("다른 활동을 선택해주세요!"); break;
					}
					
				} catch (Exception e) {
					// TODO: handle exception
				}
				
			}
		}
		
		
	}
